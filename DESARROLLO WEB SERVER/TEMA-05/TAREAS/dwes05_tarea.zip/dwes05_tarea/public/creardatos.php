<?php

require_once '../vendor/autoload.php';
require_once '../src/error_handler.php';

// <editor-fold desc="Defino alias mediante 'use'">
use App\Modelo\Jugador;
use App\Modelo\Posicion;
use App\Dao\JugadorDao;
use App\BD\BD;
use Faker\Factory;
use eftec\bladeone\BladeOne; // </editor-fold>

//Si (la invocación es invalida)
if (!isset($_POST['crear-datos'])) {
    // <editor-fold desc="Redirecciono al script index">
    header("Location:index.php");
    die(); // </editor-fold>
}
// <editor-fold desc="Creo los objetos de las librerías">
// Creo un objeto BladeOne
$views = __DIR__ . '/../views';
$cache = __DIR__ . '/../cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);
// Creo una factoría Faker
$faker = Factory::create('es_Es'); // </editor-fold>
// <editor-fold desc="Defino el número de jugadores a cargar">
define("NUM_JUGADORES", 15); // </editor-fold>
// <editor-fold desc="Establece conexión con la base de datos">
    $bd = BD::getConexion();
// </editor-fold>
$jugadorDao = new JugadorDao($bd);
//Para el número de jugadores requerido
for ($i = 0; $i < NUM_JUGADORES; $i++) { // Para el número de jugadores requerido
    // <editor-fold desc="Crea un objeto jugador">
    $jugador = new Jugador(); // </editor-fold>
    // <editor-fold desc="Solicita al jugador que establezca sus propiedades">
    $jugador->setNombre($faker->firstName('male' | 'female'));
    $jugador->setApellidos($faker->lastName . " " . $faker->lastName);
    $jugador->setDorsal($faker->unique()->numberBetween(1, 60));
    $jugador->setPosicion(Posicion::cases()[array_rand(Posicion::cases())]);
    $jugador->setBarcode($faker->unique()->ean13); // </editor-fold>
    // <editor-fold desc="Solicita al jugador que se persista">
    $jugadorDao->crea($jugador); // </editor-fold>
}
// <editor-fold desc="Redirecciona al script jugadores con el parámetro nuevosDatos">
header("Location:jugadores.php?nuevosDatos"); // </editor-fold>