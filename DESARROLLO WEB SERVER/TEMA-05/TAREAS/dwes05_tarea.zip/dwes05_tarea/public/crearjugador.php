<?php

require_once '../vendor/autoload.php';
require_once '../src/error_handler.php';

// <editor-fold desc="Define alias mediante 'use'">
use App\Modelo\Jugador;
use App\Modelo\Posicion;
use App\Dao\JugadorDao;
use App\BD\BD;
use eftec\bladeone\BladeOne;
use Faker\Factory; // </editor-fold>

// <editor-fold desc="Creo los objetos de las librerías">
$views = __DIR__ . '/../views';
$cache = __DIR__ . '/../cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG); // </editor-fold>
//
$posiciones = Posicion::cases();
//Si se solicita el formulario de creación del jugador
if (isset($_REQUEST['form-crear-jugador'])) {
    // <editor-fold desc="Invoco la vista del formulario de jugador">
    echo $blade->run('formJugador', compact('posiciones')); // </editor-fold>
}
//Sino
else if (isset($_REQUEST['generar-code']) || isset($_REQUEST['crear-jugador'])) {
    //<editor-fold desc="Establece conexión con la base de datos">
    $bd = BD::getConexion();
    // </editor-fold>
    $jugadorDao = new JugadorDAO($bd);
    if (isset($_REQUEST['generar-code'])) {
        // <editor-fold desc="Genero códigos de barras hasta que se genere uno nuevo">
        $faker = Factory::create('es_Es');
        while (true) {
            $barcode = $faker->ean13;
            if (!$jugadorDao->existeBarcode($barcode)) {
                break;
            }
        }// </editor-fold>
    }
    //<editor-fold desc="Lee los valores de nombre, apellidos, posición, dorsal y barcode">  
    $nombre = trim(filter_input(INPUT_POST, 'nombre'));
    $apellidos = trim(filter_input(INPUT_POST, 'apellidos'));
    $posicion = filter_input(INPUT_POST, 'posicion');
    $dorsal = filter_input(INPUT_POST, 'dorsal');
    $barcode = $barcode ?? trim(filter_input(INPUT_POST, 'barcode'));
    //</editor-fold>
    // Si (se solicita generar barcode)
    //  // <editor-fold desc="Establece los flags de errores en los datos del formulario">
    $errorNombre = strlen($nombre) === 0;
    $errorPosicion = is_null($posicion);
    $errorApellidos = strlen($apellidos) === 0;
    $errorBarcode = strlen($barcode) === 0;
    $errorDorsal = $dorsal && $jugadorDao->existeDorsal($dorsal);
    $error = $errorNombre || $errorApellidos || $errorDorsal || $errorBarcode || $errorPosicion; // </editor-fold>
    //Si se ha detectado algún error o se acaba de generar un código de barras
    if (($error) || isset($_REQUEST['generar-code'])) {
        // <editor-fold desc="invocar la vista del formulario con los flags de error">
        echo $blade->run('formJugador', compact('errorNombre', 'errorApellidos', 'errorDorsal', 'errorPosicion', 
                'errorBarcode', 'nombre', 'apellidos', 'dorsal', 'posicion', 'barcode', 'posiciones')); // </editor-fold>
        //Sino
    }
    // Si se solicita la creación de un jugador">
    else {
        // <editor-fold desc="Creo un nuevo jugador ">
        $dorsal = ($dorsal !== "") ? $dorsal : null;
        $jugador = new Jugador(ucwords($nombre), ucwords($apellidos), Posicion::fromString($posicion), $barcode, $dorsal); // </editor-fold>
        // <editor-fold desc="Solicito al jugador que se persista">
        $jugadorDao->crea($jugador); // </editor-fold>
        // <editor-fold desc="Redirecciono al script jugadores.php con el parámetro nuevoJugador">
        header("Location:jugadores.php?nuevoJugador"); // </editor-fold>
    }
} else {
    header("Location:jugadores.php");
}

