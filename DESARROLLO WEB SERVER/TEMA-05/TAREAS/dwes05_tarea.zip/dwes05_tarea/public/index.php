<?php

require_once '../vendor/autoload.php';
require_once '../src/error_handler.php';

// <editor-fold desc="Define alias mediante 'use'">

use App\BD\BD;
use App\Dao\JugadorDao;
use eftec\bladeone\BladeOne; // </editor-fold>

// <editor-fold desc="Creo los objetos de las librerías">
$views = __DIR__ . '/../views';
$cache = __DIR__ . '/../cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG); // </editor-fold>
// <editor-fold desc="Establece conexión con la base de datos">
$bd = BD::getConexion();
// </editor-fold>
$jugadorDao = new JugadorDao($bd);
//Si hay jugadores en la base de datos
if ($jugadorDao->numeroJugadores() > 0) {
    // <editor-fold desc="redirecciono al script jugadores.php">
    header("Location:jugadores.php?jugadores");
    die(); // </editor-fold>
}
// Sino
else {
    // <editor-fold desc="Invoco la vista de instalación">
    echo $blade->run('instalacion'); // </editor-fold>
}