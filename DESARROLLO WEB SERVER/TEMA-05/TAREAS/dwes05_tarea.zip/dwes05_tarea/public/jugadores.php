<?php

require_once '../vendor/autoload.php';
require_once '../src/error_handler.php';

// <editor-fold defaultstate="collapsed" desc="Define alias mediante 'use'">
use App\Dao\JugadorDao; 
use App\BD\BD;
use Milon\Barcode\DNS1D;
use eftec\bladeone\BladeOne; // </editor-fold>

//Si la invocación es invalida
if (empty($_REQUEST)) {
    // <editor-fold defaultstate="collapsed" desc="Redirecciono al script index">
    header("Location:index.php"); //redirecciono al script index
    die(); // </editor-fold>
}
// <editor-fold desc="Crea los objetos de las librerías">
// Creo un objeto BladeOne
$views = __DIR__ . '/../views';
$cache = __DIR__ . '/../cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);
// Creo un objeto DNS1D para los códigos de barras
$d = new DNS1D();
$d->setStorPath($cache); // </editor-fold>
// <editor-fold desc="Establece conexión con la base de datos">
$bd = BD::getConexion();
// </editor-fold>
// <editor-fold desc="Recupera la lista de jugadores de la base de datos">
$jugadorDao = new JugadorDao($bd);
try {
    $jugadores = $jugadorDao->obtenerTodos();
} catch (PDOException $ex) {
    error_log("Error al recuperar información de productos " . $ex->getMessage());
    $jugadores = [];
}// </editor-fold>
// <editor-fold desc="Establece los flags para controlar el mensaje de la cabecera de la vista jugadores">
$nuevoJugador = isset($_GET['nuevoJugador']);
$nuevosDatos = isset($_GET['nuevosDatos']); // </editor-fold>
// <editor-fold desc="Invoca a la vista jugadores con los parámetros correspondientes">
echo $blade->run('jugadores', compact('jugadores', 'd', 'nuevoJugador', 'nuevosDatos')); // </editor-fold>
