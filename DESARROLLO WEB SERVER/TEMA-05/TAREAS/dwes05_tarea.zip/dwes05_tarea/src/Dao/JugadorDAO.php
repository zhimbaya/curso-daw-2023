<?php

namespace App\Dao;

use App\Modelo\Jugador;
use App\Modelo\Posicion;
use PDO;

/**
 * Clase JugadorDAO
 */
class JugadorDAO {

    /**
     * Conexión a la base de datos
     * @var PDO
     */
    private PDO $bd;

    public function __construct($bd) {
        $this->bd = $bd;
    }

    /**
     * Crea un registro de una instancia de jugador
     * 
     * @param Jugador $jugador
     * @return type
     */
    public function crea(Jugador $jugador): void {
        $sql = "insert into jugadores (nombre, apellidos, dorsal, posicion, barcode) values (:nombre, :apellidos, :dorsal, :posicion, :barcode)";
        $stmt = $this->bd->prepare($sql);
        $resultado = $stmt->execute([
            'nombre' => $jugador->getNombre(),
            'apellidos' => $jugador->getApellidos(),
            'dorsal' => $jugador->getDorsal(),
            'posicion' => $jugador->getPosicion()->value,
            'barcode' => $jugador->getBarcode()
        ]);
        $stmt->closeCursor();
        if ($resultado) {
            $jugador->setId($this->bd->lastInsertId());
        }
    }

    /**
     * Modifica un registro de una instancia de jugador
     * 
     * @param Jugador $jugador
     * @return void
     */
    public function modifica(Jugador $jugador): void {
        $sql = "update jugadores set nombre = :nombre, apellidos = :apellidos, dorsal = :dorsal, posicion = :posicion, barcode = :barcode where id = :id";
        $stmt = $this->bd->prepare($sql);
        $stmt->execute([
            'nombre' => $jugador->getNombre(),
            'apellidos' => $jugador->getApellidos(),
            'dorsal' => $jugador->getDorsal(),
            'posicion' => $jugador->getPosicion()->value,
            'barcode' => $jugador->getBarcode(),
            'id' => $jugador->getId()
        ]);
        $stmt->closeCursor();
    }

    public function elimina(int $id): void {
        
    }

    /**
     * Obtener un jugador por su Id
     * 
     * @param int $id
     * @return Jugador
     */
    public function obtenerPorId(int $id): ?Jugador {
        
    }

    /**
     * Obtiene la lista de todos los jugadores
     * @return array
     */
    public function obtenerTodos(): array {
        $sql = "select * from jugadores order by posicion, apellidos";
        $stmt = $this->bd->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_CLASS, Jugador::class);
        $jugadores = $stmt->fetchAll();
        $stmt->closeCursor();
        array_walk($jugadores, fn ($jugador) => $this->inicializarPostPDO($jugador));
        return $jugadores;
    }

    /**
     * Cambia el valor de la propiedad de FechaNacimiento de string a DateTime
     * @param Cliente $cliente
     * @return Cliente
     */
    private function inicializarPostPDO(Jugador $jugador): Jugador {
        $posicion = Posicion::fromString($jugador->getPosicion());
        $jugador->setPosicion($posicion);
        return $jugador;
    }

    /**
     * Obtiene el número de clientes en la BD
     * @return int Número de clientes
     */
    public function numeroJugadores(): int {
        $sql = "SELECT count(*) FROM jugadores;";
        $stmt = $this->bd->query($sql);
        $numero = $stmt->fetchColumn();
        return $numero;
    }

    public function borrarTodo(): void {
        $sql = "delete from jugadores";
        $sth = $this->bd->prepare($sql);
        $sth->execute();
    }

    public function existeDorsal(int $dorsal): bool {
        $sql = "select * from jugadores where dorsal=:dorsal";
        $sth = $this->bd->prepare($sql);
        $sth->execute([':dorsal' => $dorsal]);
        return !($sth->rowCount() === 0);
    }

    public function existeBarcode(string $barcode): bool {
        $sql = "select * from jugadores where barcode=:barcode";
        $sth = $this->bd->prepare($sql);
        $sth->execute([':barcode' => $barcode]);
        return (!($sth->rowCount() === 0));
    }
}
