<?php

namespace App\Modelo;

use App\modelo\Posicion;

class Jugador {

    private int $id;
    private string $nombre;
    private string $apellidos;
    private int $dorsal;
    private $posicion;
    private string $barcode;

    public function __construct(string $nombre = null, string $apellidos = null, Posicion $posicion = null, string $barcode = null, int $dorsal = null) {
        if (func_num_args() > 0) {
            $this->setNombre($nombre);
            $this->setApellidos($apellidos);
            $this->setPosicion($posicion);
            $this->setBarcode($barcode);
            $this->setDorsal($dorsal);
        }
    }

    public function setId(int $id) {
        $this->id = $id;
    }

    public function setNombre(string $nombre) {
        $this->nombre = $nombre;
    }

    public function setApellidos(string $apellidos) {
        $this->apellidos = $apellidos;
    }

    public function setDorsal(?int $dorsal) {
        $this->dorsal = $dorsal;
    }

    public function setPosicion(Posicion $posicion) {
        $this->posicion = $posicion;
    }

    public function setBarcode(string $barcode) {
        $this->barcode = $barcode;
    }

    public function getId(): int {
        return $this->id;
    }

    public function getNombre(): string {
        return $this->nombre;
    }

    public function getApellidos(): string {
        return $this->apellidos;
    }

    public function getDorsal(): ?int {
        return $this->dorsal;
    }

    public function getPosicion() {
        return $this->posicion;
    }

    public function getBarcode(): string {
        return $this->barcode;
    }
}
