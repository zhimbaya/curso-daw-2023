<?php

namespace App\modelo;

enum Posicion: string {

    case PORTERO = 'Portero';
    case DEFENSA = 'Defensa';
    case LATERAL_IZQUIERDO = 'Lateral Izquierdo';
    case LATERAL_DERECHO = 'Lateral Derecho';
    case CENTRAL = 'Central';
    case DELANTERO = 'Delantero';

    // Método para obtener un caso de enum por su valor asociado
    public static function fromString(string $value): self {
        return self::tryFrom($value) ?? throw new \InvalidArgumentException("Valor no válido para Posicion: $value");
    }
}
