@extends('app')
@section('titulo', "Formulario Jugador")
@section('encabezado', "Nuevo Jugador")
@section('contenido')
<form name="crear" method="POST" action="crearjugador.php">
    <div class="row my-4">
        <div class="mb-3 col-md-6">
            <label for="nombre">Nombre</label>
            <input type="text" class= "{{ "form-control " . ((isset($errorNombre) && $errorNombre) ? "is-invalid" : ((isset ($nombre)) ? "is-valid" : "")) }}" id="nombre" placeholder="Nombre"
                   name="nombre" value="{{ ($nombre ?? '') }}">
            <div class="invalid-feedback">
                <p>Introduce nombre</p>
            </div>
        </div>
        <div class="mb-3 col-md-6">
            <label for="apellidos">Apellidos</label>
            <input type="text" class="{{ "form-control " . ((isset($errorApellidos) && $errorApellidos) ? "is-invalid" : ((isset ($apellidos)) ? "is-valid" : "")) }}" id="apellidos" placeholder="Apellidos"
                   name="apellidos" value="{{ ($apellidos ?? '') }}">
            <div class="invalid-feedback">
                <p>Introduce apellidos</p>
            </div>
        </div>
    </div>
    <div class="row my-4">
        <div class="form-group col-md-4">
            <label for="dorsal">Dorsal</label>
            <input type="number" class="{{ "form-control " . ((isset($errorDorsal) && $errorDorsal) ? "is-invalid" : ((isset ($dorsal)) ? "is-valid" : "")) }}" id="dorsal" placeholder="Sin asignar" name="dorsal" step="1"
                   min="1" value="{{ ($dorsal ?? '') }}">
            <div class="invalid-feedback">
                <p>Dorsal repetido</p>
            </div>
        </div>
        <div class="mb-3 col-md-4">
            <label for="posicion">Posición</label>
            <select class="{{ "form-control " . ((isset($errorPosicion) && $errorPosicion) ? "is-invalid" : ((isset ($posicion)) ? "is-valid" : "")) }}" name="posicion" id="posicion">
                <option disabled selected>Posición</option>
                @foreach ($posiciones as $posicionPosible)
                <option value="{{$posicionPosible->value }}" {{ (isset($posicion) && $posicion === $posicionPosible->value) ? 'selected' : '' }}>{{ $posicionPosible->value }}</option>
                @endforeach
            </select>
            <div class="invalid-feedback">
                <p>Introduce posición</p>
            </div>
        </div>
        <div class="mb-3 col-md-4">
            <label for="barcode">Código de Barras</label>
            <input type="text" placeholder='Código de Barras' maxlength="13" class="{{ "form-control " . ((isset($errorBarcode) && $errorBarcode) ? "is-invalid" : "") }}"
                   id="barcode" name="barcode" readonly value="{{ ($barcode ?? '') }}">
            <div class="invalid-feedback">
                <p>Genera barcode</p>
            </div>
        </div>
    </div>
    <input type="submit" class="btn btn-primary mr-3" value="Crear" name="crear-jugador">
    <input type="reset" value="Limpiar" class="btn btn-success mr-3">
    <input type="submit" formaction="jugadores.php" class="btn btn-info mr-3" value="Volver"/>
    <button class="btn btn-secondary"  name="generar-code"><i class="fa fa-barcode p-2"></i>Generar Barcode</button>
</form>
@endsection