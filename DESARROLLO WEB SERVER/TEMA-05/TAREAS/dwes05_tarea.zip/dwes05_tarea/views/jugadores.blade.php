@extends('app')
@section('titulo', "Lista Jugadores")
@section('encabezado', "Jugadores")
@section('contenido')
@if($nuevoJugador)
<div class="alert alert-success h-100 mt-3">
    <p>Nuevo jugador creado con éxito</p>
</div>
@endif
@if($nuevosDatos)
<div class="alert alert-success h-100 mt-3">
    <p>Datos de jugadores cargados con éxito</p>
</div>
@endif
<form name="Crea Jugador" action="crearjugador.php" method="POST">
    <div class="text-center">
        <input type="submit" class="btn btn-success fas fa-database m-3" name="form-crear-jugador" value="Nuevo Jugador">
    </div>
</form>
<table class="table table-striped table-dark">
    <thead>
        <tr class="text-center" style="font-width: bold; font-size:1.1rem">
            <th scope="col">Nombre Completo</th>
            <th scope="col">Posición</th>
            <th scope="col">Dorsal</th>
            <th scope="col">Código de Barras</th>
        </tr>
    </thead>
    <tbody>
        @foreach($jugadores as $item)
        <tr class="text-center">
            <th scope="row">{{$item->getApellidos().", ".$item->getNombre()}}</th>
            <td>{{$item->getPosicion()->value}}</td>
            @if (!(is_null ($item->getDorsal())))
            <td>{{$item->getDorsal()}}</td>
            @else
            <td>Sin Asignar</td>
            @endif
            <td class="d-flex justify-content-center">{!! $d->getBarcodeHTML($item->getBarcode(), 'EAN13',2,33, 'white') !!}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection