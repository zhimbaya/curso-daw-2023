<?php

//Fichero para generar las clases
require '../vendor/autoload.php';

use Wsdl2PhpGenerator\Generator;
use Wsdl2PhpGenerator\Config;

$generator = new Generator();
$generator->generate(
        new Config([
            'inputFile' => 'http://localhost/dwes06_tarea/servidorSoap/servicio.wsdl',
            'outputDir' => '../src',
            'namespaceName' => 'App'
                ])
);
