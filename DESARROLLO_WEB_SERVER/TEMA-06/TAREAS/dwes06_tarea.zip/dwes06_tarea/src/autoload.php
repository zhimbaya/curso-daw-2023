<?php


 function autoload_b0ea4b601a546a9632e8936bc4aa846a($class)
{
    $classes = array(
        'App\ClasesOperacionesService' => __DIR__ .'/ClasesOperacionesService.php'
    );
    if (!empty($classes[$class])) {
        include $classes[$class];
    };
}

spl_autoload_register('autoload_b0ea4b601a546a9632e8936bc4aa846a');

// Do nothing. The rest is just leftovers from the code generation.
{
}
