$(document).ready(function () {
    $("#login").submit(validaUsuario);
});
function validaUsuario(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    var data = $(this).serialize();
    data += '&login=' + encodeURIComponent($('input[name="login"]').val());
    $.ajax({
        type: "POST",
        url: 'index.php',
        data: data,
        dataType: "json",
        success: function (response)
        {
            if (response.login) {  
                e.target.submit();
            } else {
                $("#mensaje").removeClass("d-none");
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}
;