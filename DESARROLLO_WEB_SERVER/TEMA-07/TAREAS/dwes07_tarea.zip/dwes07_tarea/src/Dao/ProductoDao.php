<?php

namespace App\Dao;

use PDO;
use App\Modelo\Producto;

class ProductoDao {

    private PDO $bd;

    public function __construct(PDO $bd) {
        $this->bd = $bd;
    }

    public function crea(Producto $producto): bool {
       
    }

    public function modifica(Producto $producto): bool {
       
    }

    public function elimina(int $id): bool {
        
    }

    public function recuperaTodo(): array {
        $this->bd->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
        $sql = "select id, nombre, nombre_corto as nombreCorto, descripcion, pvp, familia from productos order by nombre";
        $sth = $this->bd->prepare($sql);
        $sth->execute();
        $sth->setFetchMode(PDO::FETCH_CLASS, Producto::class);
        $productos = $sth->fetchAll();
        foreach ($productos as $producto) {
            $votos = $this->recuperaVotosProducto($producto->getId());
            $puntos = $this->recuperaPuntosProducto($producto->getId());
            $producto->setVotos($votos);
            $producto->setPuntos($puntos);
        }
        return $productos;
    }

    public function recuperaProductoPorId(int $id): ?Producto {
        $this->bd->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
        $sql = "select id, nombre, nombre_corto as nombreCorto, descripcion, pvp, familia from productos where id = :id";
        $sth = $this->bd->prepare($sql);
        $sth->execute([':id' => $id]);
        $sth->setFetchMode(PDO::FETCH_CLASS, Producto::class);
        $producto = ($sth->fetch()) ?: null;
        if ($producto) {
            $votos = $this->recuperaVotosProducto($producto->getId());
            $puntos = $this->recuperaPuntosProducto($producto->getId());
            $producto->setVotos($votos);
            $producto->setPuntos($puntos);
        }
        return $producto;
    }
    
    private function recuperaVotosProducto(int $id): int {
        $sqlVotos = "select count(*) as total from votos where idPr=:idproducto";
        $sthVotos = $this->bd->prepare($sqlVotos);
        $sthVotos->execute([':idproducto' => $id]);
        $votos = ($sthVotos->fetch(PDO::FETCH_OBJ))->total;
        return $votos;
    }
    
    private function recuperaPuntosProducto(int $id): int {
        $sqlPuntos = "select IFNULL(sum(cantidad),0) as total from votos where idPr=:idproducto";
        $sthPuntos = $this->bd->prepare($sqlPuntos);
        $sthPuntos->execute([':idproducto' => $id]);
        $puntos = ($sthPuntos->fetch(PDO::FETCH_OBJ))->total;
        return $puntos;
    }

}
