<?php

namespace App\Dao;

use PDO;
use App\Modelo\Usuario;

class UsuarioDao {

    private PDO $bd;

    public function __construct(PDO $bd) {
        $this->bd = $bd;
    }

    public function crea(Usuario $usuario): bool {
        
    }

    public function modifica(Usuario $usuario): bool {
        
    }

    public function elimina(string $nombre): bool {
        
    }

    public function recuperaPorCredencial(string $nombre, string $pwd): ?Usuario{
        $pwdHashed = hash('sha256', $pwd);
        $sql = 'select * from usuarios where usuario=:nombre and pass=:pwdHashed';
        $sth = $this->bd->prepare($sql);
        $sth->execute([":nombre" => $nombre, ":pwdHashed" => $pwdHashed]);
        $sth->setFetchMode(PDO::FETCH_CLASS, Usuario::class);
        $usuario = ($sth->fetch()) ?: null;
        return $usuario;
    }

}
