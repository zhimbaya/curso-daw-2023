<?php

namespace App\Modelo;

class Usuario {

    private string $usuario;
    private string $pass;

    public function __construct(string $usuario = null, string $pass = null) {
        if (func_num_args() > 0) {
            $this->usuario = $usuario;
            $this->pass = $pass;
        }
    }

    public function getUsuario(): string {
        return $this->usuario;
    }

    public function setUsuario(string $usuario): void {
        $this->usuario = $usuario;
    }

    public function getPass(): string {
        return $this->pass;
    }

    public function setPass(string $pass): void {
        $this->pass = $pass;
    }
}
