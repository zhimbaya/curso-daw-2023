<?php

namespace App\Modelo;

class Voto {

    public int $cantidad;
    public int $idProducto;
    public string $idUsuario;

    public function __construct(int $cantidad = null, int $idProducto = null, string $idUsuario = null) {
        if (func_num_args() > 0) {
            $this->cantidad = $cantidad;
            $this->idProducto = $idProducto;
            $this->idUsuario = $idUsuario;
        }
    }

    public function getCantidad(): int {
        return $this->cantidad;
    }

    public function getIdProducto(): int {
        return $this->idProducto;
    }

    public function getIdUsuario(): string {
        return $this->idUsuario;
    }

    public function setCantidad(int $cantidad): void {
        $this->cantidad = $cantidad;
    }

    public function setIdProducto(int $idProducto): void {
        $this->idProducto = $idProducto;
    }

    public function setIdUsuario(string $idUsuario): void {
        $this->idUsuario = $idUsuario;
    }
}
