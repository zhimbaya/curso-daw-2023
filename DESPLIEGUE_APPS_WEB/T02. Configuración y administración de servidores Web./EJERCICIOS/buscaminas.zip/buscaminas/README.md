# minesweeper
*Escribe una aplicación PHP que lleve a cabo la siguiente funcionalidad:
Se trata de implementar un sencillo juego de buscaminas. La aplicación 
se encargará de colocar 8 minas en un tablero de 5x5 casillas. La colocación 
de las minas se realizará al azar con las siguientes condiciones:*

* Las minas no pueden tocarse una a otra ni siquiera por las esquinas.

* No puede haber más de tres minas en la misma fila y/o columna

*El tablero se presentará vacío al jugador que deberá marcar 1 posición donde piensa que hay una 
mina colocada y reenviarlo a la aplicación para comprobar si el jugador ha acertado. La aplicación 
mostrará de nuevo el tablero al jugador incluyendo los siguientes símbolos:*

* '+' Si la casilla ha sido marcada durante el juego, pero no había mina colocada

* '*' Si la casilla ha sido marcada durante el juego y se ha acertado en la mina 

* '-' Si la casilla está al lado de una mina descubierta y por lo tanto no puede haber ninguna mina. 

*Cuando el jugador haya acertado todas las minas del juego se mostrará una ventana 
con un mensaje de enhorabuena, el tablero en su estado final no editable y el listado de todos los disparos que ha realziado. También se le dará la posibilidad de jugar una nueva partida.*


Orientaciones:

1. Uso de funciones PHP de librería array y cadena.

2. Manejo de arrays bidimensionales.

3. Uso de funciones de usuario.

3. Uso de patrón MVC.

4. Uso de sesiones.

5. Uso de recursos de programación funcional (array_map, array_walk, array_filter, etc).

6. Uso de JavaScript para capturar eventos del interfaz en el navegador.

7. Uso de Ajax en la comunicación con el servidor.


