<?php

function createMinesField(int $width, int $height, int $numMines): array {
    $board = array_fill(0, $width, array_fill(0, $height, 0));
    $counter = 0;
    while ($counter < $numMines) {
        $i = mt_rand(0, 9);
        $j = mt_rand(0, 9);
        if ($board[$i][$j] !== 9) {
            $board[$i][$j] = 9;
            $counter++;
        }
    }
    return $board;
}

/* function createMinesField(int $width, int $height, int $numMines): array {
  $minePositions = getRandomNumberPairs($width, $height, $numMines);
  $board = array_fill(0, 10, array_fill(0, 10, 0));
  createMinesFieldRec($minePositions, $board);
  return createMinesFieldRec($minePositions, $board);
  }

  function getRandomNumberPairs(int $width, int $height, int $numMines): array {
  $numbersList = range(0, 99);
  shuffle($numbersList);
  $numbers = array_slice($numbersList, 0, $numMines);
  return (array_map(function ($number) use ($width, $height){
  return([intdiv($number, $height), $number % $width]);
  }, $numbers));
  }

  function createMinesFieldRec(array $minePositions, array $board): array {
  if (empty($minePositions)) {
  return $board;
  } else {
  return (addMine($minePositions[0], createMinesFieldRec(array_slice($minePositions, 1), $board)));
  }
  }

  function addMine($pos, $board) {
  $board[$pos[0]][$pos[1]] = 9;
  return $board;
  }

 */

function endGame(array $minesField): bool {
    $end = true;
    foreach ($minesField as $row) {
        if (min($row) < 9) {
            $end = false;
            break;
        }
    }
    return $end;
}

/* function endGame(array $minesField) {
  return min(array_map(function ($row) {
  return min($row);
  }, $minesField)) == 9;
  } */

function listMines(array $minesField): array {
    $mines = [];
    forEach ($minesField as $i => $row) {
        forEach ($row as $j => $cell) {
            if ($cell === 9) {
                $mines[$i][$j] = 9;
            }
        }
    }
    return $mines;
}

/*
  function listMines(array $minesField): array {
  $mines = [];
  foreach ($minesField as $i => $row) {
  $mines = array_merge($mines, array_map(function ($key) use ($i) {
  return [$i, $key];
  }, array_keys($row, 9)));
  }
  return $mines;
  }
 */

function neighbours(int $m, int $n, array $cell): array {
    return array_filter(array_merge(...array_map(function ($row, $columns) {
                        return array_map(function ($y) use ($row) {
                    return[$row, $y];
                }, $columns);
                    }, range(max(0, $cell[0] - 1), min($m - 1, $cell[0] + 1)),
                            (array_fill(0, min($m - 1, $cell[0] + 1) - max(0, $cell[0] - 1) + 1,
                                    range(max(0, $cell[1] - 1), min($n - 1, ($cell[1] + 1))))))),
            function ($neighbour) use ($cell) {
                return ($neighbour[0] !== $cell[0] || $neighbour[1] !== $cell[1]);
            });
}

/* function minesAdjacentCell(array $minesField, array $mine): int {
  return match ($minesField[$mine[0]][$mine[1]]) {
  9 => 9,
  default => count(array_filter(array_map(function ($cell) use ($minesField) {
  return $minesField[$cell[0]][$cell[1]];
  }, neighbours(count($minesField), count($minesField[0]), $mine)), function ($mine) {
  return $mine === 9;
  }))
  };
  } */

function noMinesNeighbours(array $minesAdjacentField, array $mine): array {
    return array_filter(neighbours(count($minesAdjacentField), count($minesAdjacentField[0]), $mine), function ($mine) use ($minesAdjacentField) {
        return $minesAdjacentField[$mine[0]][$mine[1]] === 0;
    });
}

/* function minesAdjacentField(array $minesField): array {
  $minesAdjacentField = array();
  foreach ($minesField as $i => $row) {
  foreach ($row as $j => $mine) {
  $minesAdjacentField[$i][$j] = minesAdjacentCell($minesField, [$i, $j]);
  }
  }
  return $minesAdjacentField;
  } */

function adjacentCells(array $minesField, array $cell): array {
    $rowsNumber = count($minesField);
    $columnsNumber = count($minesField[0]);
    // $cells = array(array());
    for ($i = max(0, $cell[0] - 1); $i <= min($rowsNumber - 1, $cell[0] + 1); $i++) {
        for ($j = max(0, $cell[1] - 1); $j <= min($columnsNumber - 1, $cell[1] + 1); $j++) {
            // if ($i !== $cell[0] || $j !== $cell[1]) {
            $cells[$i][$j] = $minesField[$i][$j];
            // }
        }
    }
    return $cells;
}

function minesAdjacentCell(array $minesField, array $cell): int {
    return (count(array_keys(array_merge(...adjacentCells($minesField, $cell)), 9)));
}

function minesAdjacentField(array $minesField): array {
    $minesAdjacentField = array_merge(array(), $minesField);
    foreach ($minesField as $i => $row) {
        foreach ($row as $j => $cell) {
            if ($minesField[$i][$j] !== 9) {
                $minesAdjacentField[$i][$j] = minesAdjacentCell($minesField, [$i, $j]);
            }
        }
    }
    return $minesAdjacentField;
}

/* function noMinesConnected(array $minesAdjacentField, array $mine): array {
  if ($minesAdjacentField[$mine[0]][$mine[1]] !== 0) {
  return array();
  } else {
  return noMinesConnectedRec($minesAdjacentField, [$mine], noMinesNeighbours($minesAdjacentField, $mine));
  }
  } */

function noMinesConnectedRec(array $minesAdjacentField, array $noMines, array $noMinesNeighbours): array {
    if (empty($noMinesNeighbours)) {
        return $noMines;
    } else {
        $noMine = array_slice($noMinesNeighbours, 0, 1)[0];
        if (in_array($noMine, $noMines)) {
            return noMinesconnectedRec($minesAdjacentField, $noMines, array_slice($noMinesNeighbours, 1));
        }
        return noMinesconnectedRec($minesAdjacentField, array_merge($noMines, [$noMine]),
                array_merge(array_slice($noMinesNeighbours, 1), array_filter(neighbours(count($minesAdjacentField), count($minesAdjacentField[0]), $noMine),
                                function ($noMine2) use ($minesAdjacentField) {
                                    return ($minesAdjacentField[$noMine2[0]][$noMine2[1]] === 0);
                                }
        )));
    }
}

function noMinesConnected(array $minesField, array $cellCoor): array {
    $noMinesConnected = array();
    $cellsToCheck = [$cellCoor];
    $cellsChecked = [];
    $noMinesConnected[$cellCoor[0]][$cellCoor[1]] = 0;
    while (!(empty($cellsToCheck))) {
        $cellToCheck = array_pop($cellsToCheck);
        if (array_search($cellToCheck, $cellsChecked) === false) {
            $cellsChecked[] = $cellToCheck;
            $neighbourField = adjacentCells($minesField, $cellToCheck);
            foreach ($neighbourField as $i => $neighbourRow) {
                foreach ($neighbourRow as $j => $neighbourCell) {
                    if ($neighbourCell === 0) {
                        $cellsToCheck = array_merge($cellsToCheck, [[$i, $j]]);
                    }
                    if ($neighbourCell < 9) {
                        $noMinesConnected[$i][$j] = $neighbourCell;
                    }
                }
            }
        }
    }
    return $noMinesConnected;
}
