<?php

/*
 * A continuación se detallan los mensajes que le pueden llegar
 * al controlador y la lógica de proceso para cada uno de ellos.
 * 
 * - Petición Inicial o Proceso de Botón de Nuevo Juego
 *   -- Inicializo el tablero con cadenas vacías
 *   -- Almaceno el tablero en $_SESSION
 *   -- Mostrar la vista "move" para que el jugador empiece a jugar.
 * - Proceso Jugada (Petición hecha por medio de AJAX)
 *   -- Leer la celda seleccionada
 *   -- Modificar el estado del tablero
 *   -- Si hay tres en raya mostrar el mensaje de final partida informando de la victoria del jugador
 *      sino Si hay tablas mostrar el mensaje de tablas informando de las tablas
 *         sino generar la jugada del computador
 *              Modificar el estado del tablero
 *              si hay tres en raya mostrar el mensaje de final partida informando de la victoria del computador
 *              sino  Si hay tablas mostrar el mensaje de tablas informando de las tablas
 *                sino  Almacenar el estado del tablero en la sesión
 *                      devolver el movimiento hecho por el ordenador con la respuesta AJAX
 *                            
 */


define("BOARD_WITH", 10);
define("BOARD_HEIGHT", 10);
define("NUM_MINES", 10);
define("PIC_ICON", "public/assets/img/icon.svg");
define("PIC_FROWNY", "public/assets/img/frowny.svg");
define("PIC_SMILEY", "public/assets/img/smiley.svg");
define("PIC_1", "public/assets/img/1.svg");
define("PIC_2", "public/assets/img/2.svg");
define("PIC_3", "public/assets/img/3.svg");
define("PIC_4", "public/assets/img/4.svg");
define("PIC_5", "public/assets/img/5.svg");
define("PIC_6", "public/assets/img/6.svg");
define("PIC_7", "public/assets/img/7.svg");
define("PIC_8", "public/assets/img/8.svg");
define("PIC_FLAG", "public/assets/img/flag.svg");
define("PIC_BOMB", "public/assets/img/mine.png");
define("PIC_OPENED", "public/assets/img/opened.svg");

require "vendor/autoload.php";
require_once "functions.php";

use eftec\bladeone\BladeOne;

session_start();

$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache'; // (optional) 1=forced (test),2=run fast (production), 0=automatic, default value.
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

$blade->setBaseUrl("http://{$_SERVER['SERVER_NAME']}:{$_SERVER['SERVER_PORT']}/");

$blade->addAssetDict('js/jquery.min.js', 'https://code.jquery.com/jquery-3.6.0.min.js');

if (empty($_POST)) {
    $minesField = createMinesfield(BOARD_WITH, BOARD_HEIGHT, NUM_MINES);
    $minesAdjacentField = minesAdjacentField($minesField);
    $_SESSION['minesField'] = $minesAdjacentField;
    echo $blade->run('move', ['width' => BOARD_WITH, 'height' => BOARD_HEIGHT]);
} elseif (!empty($_POST['reset'])) {
    $minesField = createMinesfield(BOARD_WITH, BOARD_HEIGHT, NUM_MINES);
    $minesAdjacentField = minesAdjacentField($minesField);
    $_SESSION['minesField'] = $minesAdjacentField;
    header('Content-type: application/json');
    echo json_encode(true);
} else {
    $response = [];
    $minesField = $_SESSION['minesField'];
    $i = filter_input(INPUT_POST, 'i', FILTER_VALIDATE_INT);
    $j = filter_input(INPUT_POST, 'j', FILTER_VALIDATE_INT);
    if ($minesField[$i][$j] === 9) {
        $response['cells'] = listMines($minesField);
        $response['status'] = false;
    } else if ($minesField[$i][$j] > 0) {
        $response['cells'] = [$i => [$j => $minesField[$i][$j]]];
        $minesField[$i][$j] = $minesField[$i][$j] + 10;
        if (endGame($minesField)) {
            $response['status'] = true;
        }
    } else {
        $cells = noMinesConnected($minesField, [$i, $j]);
        $response['cells'] = $cells;
        foreach ($cells as $i => $row) {
            foreach ($row as $j => $cell) {
                $minesField[$i][$j] = $minesField[$i][$j] + 10;
            }
        }
    }
    $_SESSION['minesField'] = $minesField;
    header('Content-type: application/json');
    echo json_encode($response, JSON_FORCE_OBJECT);
}