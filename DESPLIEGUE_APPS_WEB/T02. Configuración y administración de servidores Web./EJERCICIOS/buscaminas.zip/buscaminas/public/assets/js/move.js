function reset(e) {
    $.ajax({
        type: 'POST',
        url: 'index.php',
        dataType: 'json',
        data: {
            reset: true
        },
        success: function (results) {
            console.log(results);
            resetBoard();
        }
    });
}

function checkPosition(e) {
    var mine = e.currentTarget;
    $.ajax({
        type: 'POST',
        url: 'index.php',
        dataType: 'json',
        data: {
            i: mine.dataset.i,
            j: mine.dataset.j
        },
        success: function (results) {
            console.log(results.cells);
            if (results.cells !== undefined) {
                cells = results.cells;
                for (let propX in cells) {
                    for (let propY in cells[propX]) {
                        $(`#${propX}-${propY}`).addClass("spacenoborder");
                        $(`#${propX}-${propY}`).empty();
                        $(`#${cells[propX][propY]}`).clone().removeClass("master").addClass("hintimg").appendTo($(`#${propX}-${propY}`));
                        $(`#${propX}-${propY}`).unbind('click');
                    }
                }
            }
            if (results.status !== undefined) {
                if (!results.status) {
                    $(".space").unbind('click');
                    $(".space").unbind('contextmenu');
                    $(`#face`).empty();
                    $(`#frowny`).clone().removeClass("master").addClass("hintimg").appendTo($(`#face`));
                    setTimeout(() => {
                        alert("Lo siento. Has perdido");
                    }, 10);
                } else {
                    alert("Enhorabuena. Has ganado");
                }
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText;
            alert('Error - ' + errorMessage);
        }});
}


function resetBoard() {
    $(".space").each(function (index, node) {
        $(node).empty();
        $(node).removeClass("spacenoborder");
    });
    $(`#face`).empty();
    $(`#smiley`).clone().removeClass("master").addClass("hintimg").appendTo($(`#face`));
    $(".space").click(checkPosition);
    $(".space").contextmenu(addFlag);
}

function addFlag(e) {
    e.preventDefault();
    if ($(`#${e.currentTarget.dataset.i}-${e.currentTarget.dataset.j}`).is((':empty'))) {
        $(`#${e.currentTarget.dataset.i}-${e.currentTarget.dataset.j}`).addClass("spacenoborder");
        $(`#10`).clone().removeClass("master").addClass("hintimg").appendTo($(`#${e.currentTarget.dataset.i}-${e.currentTarget.dataset.j}`));
    } else {
        $(`#${e.currentTarget.dataset.i}-${e.currentTarget.dataset.j}`).empty();
        $(`#${e.currentTarget.dataset.i}-${e.currentTarget.dataset.j}`).removeClass("spacenoborder");
    }
    return false;
}
// Function to add event listener to t
function load() {
    $(".space").click(checkPosition);
    $(".space").contextmenu(addFlag);
    $("#face").click(reset);
}

document.addEventListener("DOMContentLoaded", load);

