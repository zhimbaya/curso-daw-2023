<!DOCTYPE html>
<html>
    <head>
        @base
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>@yield('title')</title>
        <link rel="stylesheet" type="text/css" href="@asset('public/assets/css/stylesheet.css')">
    </head>
    <body>
        <main>
            <header class="menu">
                <img class="icon" src="@asset(PIC_ICON)" width="28" height="28"/>
                <h1>Minesweeper</h1>
            </header>
            <section>
                <img class="master" id="frowny" src="@asset(PIC_FROWNY)"/>
                <img class="master" id="smiley" src="@asset(PIC_SMILEY)" />
                <img class="master" id="0" src="@asset(PIC_OPENED)" />
                <img class="master" id="1" src="@asset(PIC_1)" />
                <img class="master" id="2" src="@asset(PIC_2)" />
                <img class="master" id="3" src="@asset(PIC_3)" />
                <img class="master" id="4" src="@asset(PIC_4)" />
                <img class="master" id="5" src="@asset(PIC_5)" />
                <img class="master" id="6" src="@asset(PIC_6)" />
                <img class="master" id="7" src="@asset(PIC_7)" />
                <img class="master" id="8" src="@asset(PIC_8)" />
                <img class="master" id="9" src="@asset(PIC_BOMB)" />
                <img class="master" id="10" src="@asset(PIC_FLAG)" />
            </section>
            @yield('content')
        </main>
        <script src="@asset('js/jquery.min.js')" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="@asset('public/assets/js/move.js')"></script>
    </body>
</html>

