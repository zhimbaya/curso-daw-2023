<div class="minesweeper">
    <section class="game">
        <div class="controls">
            <button id="face" type="button" class="reset">
                <img src="@asset(PIC_SMILEY)" alt="" />
            </button>
        </div>
        <div class="board">
            @for ($i=0; $i<$width; $i++)
            @for ($j=0; $j<$height; $j++)
            <button id='{{"$i-$j"}}' data-i="{{$i}}" data-j="{{$j}}" class="space"></button>
            @endfor
            @endfor
        </div>
    </section>
</div>

